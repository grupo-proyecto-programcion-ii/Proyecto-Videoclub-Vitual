INSERT INTO `musica` VALUES (1,'1965-07-02','Scorpions',3,20,'Klaus',1965,'UFO'),(2,'2019-03-06','Ramin Djawadi',2,10,'Sont',2019,'HBO'),(3,'1953-03-06','Blue Moon',2,10,'Elvis',1953,'HVM'),(4,'2002-11-04','El tiempo y el espacio',5,8,'Pignois',2002,'Iuno Records');

INSERT INTO `peliculas` VALUES (1,'2005-05-12','El reino de los cielos',3,2.3,18,97),(2,'2009-03-12','El curioso caso de Benjamin Button',2,2.2,12,85),(3,'2011-08-12','Drive',5,1.5,18,98),(4,'2012-03-12','Cruce de caminos',5,1.35,12,83),(5,'2014-11-12','Interstellar',6,2.1,16,94),(6,'2001-02-02','Una mente maravillosa',1,2.03,6,89),(7,'2012-08-02','Django',2,1.4,18,79),(8,'1994-07-12','Pulp Fiction',3,2.1,18,96);

INSERT INTO `usuarios` VALUES (1,'admin','admin','Asier','Marin Fernandez','asier.marin@opendeusto.es','234556456465BS','1997-01-18',0,0,'2019-05-31');

INSERT INTO `videojuegos` VALUES (1,'2007-08-24','Crysis',4,30,96,18),(2,'1998-08-23','StarCraft',1,60,93,2),(3,'2008-11-23','Dark Souls',6,110,100,12),(4,'1998-07-23','Half Life',2,40,92,12);